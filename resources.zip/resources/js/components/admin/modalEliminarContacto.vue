<template>
    <vue-js-modal name="modalEliminarContacto">
        Dialogo de prueba
    </vue-js-modal>
</template>

<script>
export default {
name: "modalEliminarContacto"
}
</script>

<style scoped>

</style>
