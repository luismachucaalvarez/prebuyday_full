<template>
    <section class="bg-lightpink" data-aos="fade-right">
    <div class="container py-8 flex md:flex-row-reverse flex-wrap">
        <div class="px-4 w-full sm:w-full md:w-1/2 lg:w-1/2" >
            <div class="border-b-8 border-violet">
                <h3 class="text-2xl uppercase italic font-bold">Nuestro principal foco</h3>
            </div>
            <div class="py-4">
                <p class="lg:text-xl">Es dar una vitrina de calidad para emprendedores como pequeños y medianos productores chilenos o extranjeros pero que operen en nuestro país, pasando a ser al mismo tiempo un apoyo en la venta de sus productos, donde esperamos cooperar
                    de forma importante en el desarrollo y crecimiento de cada vendedor.</p>
            </div>

        </div>
        <div class=" w-full md:w-1/2" data-aos="fade-left">
            <img src="/img/img_nuestrofoco.jpg" alt="¿Quienes somos?" class="h-full w-full object-cover">
        </div>
    </div>
    </section>
</template>

<script>
export default {
    name: "NuestroFoco"
}
</script>

<style scoped>

</style>
