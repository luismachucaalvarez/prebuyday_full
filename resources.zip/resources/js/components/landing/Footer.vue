<template>
    <div class="bg-darkviolet px-4 h-16 md:h-8" >
        <div class="container flex sm:flex-row flex-col md:py-1">
            <nav class=" w-full md:w-1/2 text-center text-white flex flex-col md:flex-row">
                <a class="text-sm px-2">Tratamiento de datos</a>
                <a class="text-sm px-2">Créditos</a>

            </nav>
            <p class="text-sm text-center text-white md:text-right w-full md:w-1/2">Buyday.cl &copy; 2020. Todos los derechos reservados</p>
        </div>
    </div>
</template>

<script>
export default {
name: "Footer"
}
</script>

<style scoped>

</style>
