Nombre: {{ $name }}
Email: {{ $email }}
