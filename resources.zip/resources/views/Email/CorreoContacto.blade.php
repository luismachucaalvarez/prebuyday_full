@component('mail::message')


    The body of your message.

    Thanks,<br>
    {{ config('app.name') }}
@endcomponent
