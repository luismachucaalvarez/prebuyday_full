@component('mail::message')

    Hola, {{ $mailData['nombre_contacto'] }}:

    En primer lugar, muchas gracias por darte de alta en nuestro sitio.

    Te contamos que estamos haciendo los preparativos para la apertura de nuestro marketplace, y si todo sale bien, estaremos online en la primera quincena de noviembre.

    Saludos, tus amigos de Buyday.cl



@endcomponent
