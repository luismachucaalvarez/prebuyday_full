@component('mail::message')

    Hola, {{ $mailData['nombre_contacto'] }}:

    En primer lugar, muchas gracias por darte de alta en nuestro sitio.

    Te contamos que estamos haciendo los preparativos para la apertura de nuestro marketplace, y si todo sale bien, estaremos online en la primera quincena de noviembre.

    Ahora, nos dijiste que no has realizado iniciación de actividades. Esto en sí no es malo, pero te contamos que establecimos esto como requisito fundamental para postular a nuestro marketplace.

    Bienvenido nuevamente,

    Saludos, tus amigos de Buyday.cl


@endcomponent
