<h2>Mensaje: {{$msj}}</h2>
<h2>Mensaje: {{$nombre_completo}}</h2>
