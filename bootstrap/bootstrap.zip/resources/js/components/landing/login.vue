<template>
<h2>Prueba</h2>
</template>

<script>
export default {
name: "login"
}
</script>

<style scoped>

</style>
