<template>
    <!--<section class="subhero-pattern bg-center bg-cover  text-center pb-64" data-aos="fade-up" data-aos-delay="2000">-->
    <section class="text-center pb-50 py-16" data-aos="fade-up" data-aos-delay="1000">


        <div class="container">
            <div class=" sm: px-2 items-center">
                <div class="border-b-8 border-violet">
                    <h2 class="text-2xl uppercase italic text-center font-bold text-black">Todo esto a cambio de una comisión por cada venta</h2>
                </div>
                <div class="flex md:flex-row-reverse flex-wrap">
                    <div class=" w-full md:w-1/2" data-aos="fade-right">
                        <img src="../../../img/img_comision.png" class="h-48 w-full object-contain"/>
                    </div>
                    <div class="px-4 py-8 w-full md:w-1/2 lg:w-1/2" data-aos="fade-left">
                        <p class="text-xl text-center text-black lg:py-4">De esta forma, podemos seguir creciendo para ustedes. Esta comisión dependerá de la categoría de tus productos.</p>
                    </div>
                </div>
            </div>
        </div>

    </section>
</template>

<script>
export default {
    name: "SeccionComision"
}
</script>

<style scoped>

</style>
