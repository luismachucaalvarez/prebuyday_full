<template>
    <section id="quienesSomos" data-aos="fade-right">
        <!-- Seccion quienes somos -->
        <div class="py-8 flex flex-wrap container ">
            <div class="px-4 w-full sm:w-full md:w-1/2 lg:w-1/2" >
                <div class="border-b-8 border-violet">
                    <h3 class="text-2xl uppercase italic font-bold">¿Quienes somos?</h3>
                </div>
                <div class="py-4">
                    <p class="lg:text-xl">¿Qué quiénes somos?, tienen razón… conozcámonos primero. Somos BUYDAY.CL, un nuevo portal de venta de e-Commerce en formato Marketplace, para ustedes y sus productos, damos el espacio para la publicación de productos, ya sea para emprendedores
                        o pequeñas empresas, lo más importante es apoyar a empresas chilenas o que desempeñen en nuestro territorio, y obviamente, con la calidad que los destaca. </p>
                </div>
            </div>
            <div class=" w-full md:w-1/2" data-aos="fade-left">
                <img src="/img/img_quienessomos.jpg" alt="¿Quienes somos?" class="h-full w-full object-cover">
            </div>
        </div>

    </section>
    <!-- Fin sección quienes somos -->
</template>

<script>
export default {
    name: "QuienesSomos",
}
</script>

<style scoped>

</style>
