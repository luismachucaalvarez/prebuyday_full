<template>
    <section class="bg-lightgrayishred" data-aos="fade-up">
        <!-- Que hacemos-->
        <div class="py-4">
            <div class="container border-b-8 border-violet">
                <h2 class="text-3xl uppercase italic text-center font-bold">Lo qué podemos ofrecer</h2>
            </div>
            <div class="container py-8">
                <p class="text-center">Dispondremos para ustedes una interesante plataforma, donde podrás crear tu propia tienda y subir los productos que necesitas vender. Pero nuestra intención no es quedarnos solo con eso:</p>
                <div class="py-8 grid md:grid-cols-2 lg:grid-cols-4">
                    <div class="p-4" data-aos="fade-up" data-aos-delay="700">
                        <img class="h-32 w-full object-contain" src="/img/img_servicio1.png" alt="">
                        <h3 class="py-4 text-4x1 text-center uppercase font-bold">Tus productos, tu imagen</h3>
                        <p class=" py-2 text-center">Tendrás tu propia tienda. Nosotros nos preocupamos de vender, tú de poner tus productos en vitrina y tu marca.</p>
                    </div>
                    <div class="p-4" data-aos="fade-up" data-aos-delay="1400">
                        <img class="h-32 w-full object-contain" src="/img/img_servicio2.png" alt="">
                        <h3 class="py-4 text-4x1 text-center uppercase font-bold">Una avanzada plataforma administrativa</h3>
                        <p class=" py-2 text-center">A través de la misma consola de administración podrás ver información detallada de tus ventas, tus publicaciones que ya se encuentran en línea, tráfico, entre otras funciones.</p>
                    </div>
                    <div class="p-4" data-aos="fade-up" data-aos-delay="2100">
                        <img class="h-32 w-full object-contain" src="/img/img_servicio3.png" alt="">
                        <h3 class="py-4 text-4x1 text-center uppercase font-bold">Del marketing no te preocupes</h3>
                        <p class=" py-2 text-center">Nos encargaremos de realizar constantes campañas de marketing, en diferentes medios y plataformas. Tú solo te encargas de publicar tus productos.
                        </p>
                    </div>
                    <div class="p-4" data-aos="fade-up" data-aos-delay="2800">
                        <img class="h-32 w-full object-contain" src="/img/img_servicio4.png" alt="">
                        <h3 class="py-4 text-4x1 text-center uppercase font-bold">¿No cuentas con despacho?</h3>
                        <p class=" py-2 text-center">No hay problema, nosotros nos encargamos de la logística y la entrega de los productos a tus clientes
                        </p>
                    </div>
                </div>
            </div>

        </div>

    </section>
</template>

<script>
export default {
name: "QueHacemos"
}
</script>

<style scoped>

</style>
