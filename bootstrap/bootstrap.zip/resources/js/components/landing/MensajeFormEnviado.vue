<template>

</template>

<script>
export default {
name: "MensajeFormEnviado"
}
</script>

<style scoped>

</style>
