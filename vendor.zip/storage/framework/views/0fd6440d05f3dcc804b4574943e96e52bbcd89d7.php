<h2>Mensaje: <?php echo e($msj); ?></h2>
<h2>Mensaje: <?php echo e($nombre_completo); ?></h2>
<?php /**PATH D:\laragon\www\prebuyday\resources\views/email.blade.php ENDPATH**/ ?>