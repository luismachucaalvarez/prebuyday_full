<?php $__env->startComponent('mail::message'); ?>

Hola:

    Te notificamos que se acaba de registrar un nuevo vendedor en el sistema de Preinscripcion:

    Nombre Completo: <?php echo e($mailData['nombre_contacto']); ?>

    Telefono de contacto: <?php echo e($mailData['telefono_contacto']); ?>

    Correo: <?php echo e($mailData['email_contacto']); ?>

    Nombre Fantasia Comercio: <?php echo e($mailData['nombre_fantasia_comercio']); ?>

    Iniciación de actividades: <?php echo e($mailData['iniciacion']); ?>



<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\laragon\www\prebuyday\resources\views/Email/correoNotificacionAdminSinIniciacion.blade.php ENDPATH**/ ?>