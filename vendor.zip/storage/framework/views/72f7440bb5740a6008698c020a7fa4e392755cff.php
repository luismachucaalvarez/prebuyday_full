Nombre: <?php echo e($data['nombre']); ?>

<?php /**PATH D:\laragon\www\prebuyday\resources\views/emailcontacto.blade.php ENDPATH**/ ?>