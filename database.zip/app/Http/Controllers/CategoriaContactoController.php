<?php

namespace App\Http\Controllers;

use App\Models\CategoriaContacto;
use Illuminate\Http\Request;

class CategoriaContactoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\CategoriaContacto  $categoriaContacto
     * @return \Illuminate\Http\Response
     */
    public function show(CategoriaContacto $categoriaContacto)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\CategoriaContacto  $categoriaContacto
     * @return \Illuminate\Http\Response
     */
    public function edit(CategoriaContacto $categoriaContacto)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\CategoriaContacto  $categoriaContacto
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CategoriaContacto $categoriaContacto)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\CategoriaContacto  $categoriaContacto
     * @return \Illuminate\Http\Response
     */
    public function destroy(CategoriaContacto $categoriaContacto)
    {
        //
    }
}
